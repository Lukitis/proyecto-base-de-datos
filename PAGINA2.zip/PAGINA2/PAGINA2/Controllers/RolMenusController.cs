﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PAGINA2.Models;

namespace PAGINA2.Controllers
{
    public class RolMenusController : Controller
    {
        private readonly DbventaContext _context;

        public RolMenusController(DbventaContext context)
        {
            _context = context;
        }

        // GET: RolMenus
        public async Task<IActionResult> Index()
        {
            var dbventaContext = _context.RolMenus.Include(r => r.IdMenuNavigation).Include(r => r.IdRolNavigation);
            return View(await dbventaContext.ToListAsync());
        }

        // GET: RolMenus/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rolMenu = await _context.RolMenus
                .Include(r => r.IdMenuNavigation)
                .Include(r => r.IdRolNavigation)
                .FirstOrDefaultAsync(m => m.IdRolMenu == id);
            if (rolMenu == null)
            {
                return NotFound();
            }

            return View(rolMenu);
        }

        // GET: RolMenus/Create
        public IActionResult Create()
        {
            ViewData["IdMenu"] = new SelectList(_context.Menus, "IdMenu", "IdMenu");
            ViewData["IdRol"] = new SelectList(_context.Rols, "IdRol", "IdRol");
            return View();
        }

        // POST: RolMenus/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdRolMenu,IdRol,IdMenu,EsActivo,FechaRegistro")] RolMenu rolMenu)
        {
            if (ModelState.IsValid)
            {
                _context.Add(rolMenu);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdMenu"] = new SelectList(_context.Menus, "IdMenu", "IdMenu", rolMenu.IdMenu);
            ViewData["IdRol"] = new SelectList(_context.Rols, "IdRol", "IdRol", rolMenu.IdRol);
            return View(rolMenu);
        }

        // GET: RolMenus/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rolMenu = await _context.RolMenus.FindAsync(id);
            if (rolMenu == null)
            {
                return NotFound();
            }
            ViewData["IdMenu"] = new SelectList(_context.Menus, "IdMenu", "IdMenu", rolMenu.IdMenu);
            ViewData["IdRol"] = new SelectList(_context.Rols, "IdRol", "IdRol", rolMenu.IdRol);
            return View(rolMenu);
        }

        // POST: RolMenus/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdRolMenu,IdRol,IdMenu,EsActivo,FechaRegistro")] RolMenu rolMenu)
        {
            if (id != rolMenu.IdRolMenu)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(rolMenu);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RolMenuExists(rolMenu.IdRolMenu))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdMenu"] = new SelectList(_context.Menus, "IdMenu", "IdMenu", rolMenu.IdMenu);
            ViewData["IdRol"] = new SelectList(_context.Rols, "IdRol", "IdRol", rolMenu.IdRol);
            return View(rolMenu);
        }

        // GET: RolMenus/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rolMenu = await _context.RolMenus
                .Include(r => r.IdMenuNavigation)
                .Include(r => r.IdRolNavigation)
                .FirstOrDefaultAsync(m => m.IdRolMenu == id);
            if (rolMenu == null)
            {
                return NotFound();
            }

            return View(rolMenu);
        }

        // POST: RolMenus/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var rolMenu = await _context.RolMenus.FindAsync(id);
            if (rolMenu != null)
            {
                _context.RolMenus.Remove(rolMenu);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RolMenuExists(int id)
        {
            return _context.RolMenus.Any(e => e.IdRolMenu == id);
        }
    }
}
